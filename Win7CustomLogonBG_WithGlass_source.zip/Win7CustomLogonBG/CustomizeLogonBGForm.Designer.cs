﻿namespace Win7CustomLogonBG
{
    partial class CustomizeLogonBGForm
    {
        #region Fields 

        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        private System.Windows.Forms.Button applyButton;

        private System.Windows.Forms.Button refreshButton;

        private System.Windows.Forms.CheckBox enableCustomBackgroundCheckBox;

        private System.Windows.Forms.ColumnHeader Filename;

        private System.Windows.Forms.Label currentLabel;

        private System.Windows.Forms.Label newLabel;

        private System.Windows.Forms.ListView listView;

        private System.Windows.Forms.Panel glassPanel;

        private System.Windows.Forms.Panel headerPanel;

        private System.Windows.Forms.Panel monitorsPanel;

        #endregion Fields 

        #region Methods 

        #region Protected Methods 

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                if (currentBackground != null)
                {
                    currentBackground.Dispose();
                    currentBackground = null;
                }

                if (selectedBackground != null)
                {
                    selectedBackground.Dispose();
                    selectedBackground = null;
                }

                if (components != null)
                    components.Dispose();
            }
            base.Dispose(disposing);
        }

        #endregion Protected Methods 

        #region Private Methods 

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(CustomizeLogonBGForm));
            this.applyButton = new System.Windows.Forms.Button();
            this.refreshButton = new System.Windows.Forms.Button();
            this.glassPanel = new System.Windows.Forms.Panel();
            this.listView = new System.Windows.Forms.ListView();
            this.Filename = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.headerPanel = new System.Windows.Forms.Panel();
            this.currentLabel = new System.Windows.Forms.Label();
            this.newLabel = new System.Windows.Forms.Label();
            this.enableCustomBackgroundCheckBox = new System.Windows.Forms.CheckBox();
            this.monitorsPanel = new System.Windows.Forms.Panel();
            this.glassPanel.SuspendLayout();
            this.headerPanel.SuspendLayout();
            this.SuspendLayout();
            // 
            // applyButton
            // 
            this.applyButton.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.applyButton.Enabled = false;
            this.applyButton.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.applyButton.Location = new System.Drawing.Point(485, 371);
            this.applyButton.Name = "applyButton";
            this.applyButton.Size = new System.Drawing.Size(256, 28);
            this.applyButton.TabIndex = 4;
            this.applyButton.Text = "Apply selected background";
            this.applyButton.UseVisualStyleBackColor = true;
            this.applyButton.Click += new System.EventHandler(this.ApplyButton_Click);
            // 
            // refreshButton
            // 
            this.refreshButton.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.refreshButton.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.refreshButton.Location = new System.Drawing.Point(0, 371);
            this.refreshButton.Name = "refreshButton";
            this.refreshButton.Size = new System.Drawing.Size(161, 28);
            this.refreshButton.TabIndex = 3;
            this.refreshButton.Text = "Refresh";
            this.refreshButton.UseVisualStyleBackColor = true;
            this.refreshButton.Click += new System.EventHandler(this.RefreshButton_Click);
            // 
            // glassPanel
            // 
            this.glassPanel.BackColor = System.Drawing.Color.Magenta;
            this.glassPanel.Controls.Add(this.listView);
            this.glassPanel.Controls.Add(this.applyButton);
            this.glassPanel.Controls.Add(this.headerPanel);
            this.glassPanel.Controls.Add(this.monitorsPanel);
            this.glassPanel.Controls.Add(this.refreshButton);
            this.glassPanel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.glassPanel.Location = new System.Drawing.Point(0, 0);
            this.glassPanel.Name = "glassPanel";
            this.glassPanel.Size = new System.Drawing.Size(741, 399);
            this.glassPanel.TabIndex = 10;
            // 
            // listView
            // 
            this.listView.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(196)))), ((int)(((byte)(198)))), ((int)(((byte)(201)))));
            this.listView.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.Filename});
            this.listView.FullRowSelect = true;
            this.listView.HideSelection = false;
            this.listView.Location = new System.Drawing.Point(0, 58);
            this.listView.Name = "listView";
            this.listView.Size = new System.Drawing.Size(161, 291);
            this.listView.TabIndex = 1;
            this.listView.UseCompatibleStateImageBehavior = false;
            this.listView.View = System.Windows.Forms.View.Details;
            this.listView.ItemSelectionChanged += new System.Windows.Forms.ListViewItemSelectionChangedEventHandler(this.ListView_ItemSelectionChanged);
            this.listView.DoubleClick += new System.EventHandler(this.ListView_DoubleClick);
            // 
            // Filename
            // 
            this.Filename.Text = "Filename";
            this.Filename.Width = 25;
            // 
            // headerPanel
            // 
            this.headerPanel.BackgroundImage = global::Win7CustomLogonBG.Properties.Resources.gradient;
            this.headerPanel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.headerPanel.Controls.Add(this.currentLabel);
            this.headerPanel.Controls.Add(this.newLabel);
            this.headerPanel.Controls.Add(this.enableCustomBackgroundCheckBox);
            this.headerPanel.Dock = System.Windows.Forms.DockStyle.Top;
            this.headerPanel.Location = new System.Drawing.Point(0, 0);
            this.headerPanel.Name = "headerPanel";
            this.headerPanel.Size = new System.Drawing.Size(741, 36);
            this.headerPanel.TabIndex = 0;
            // 
            // currentLabel
            // 
            this.currentLabel.BackColor = System.Drawing.Color.Transparent;
            this.currentLabel.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.currentLabel.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.currentLabel.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(65)))), ((int)(((byte)(65)))), ((int)(((byte)(68)))));
            this.currentLabel.Location = new System.Drawing.Point(211, 9);
            this.currentLabel.Name = "currentLabel";
            this.currentLabel.Size = new System.Drawing.Size(226, 17);
            this.currentLabel.TabIndex = 1;
            this.currentLabel.Text = "Current";
            this.currentLabel.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // newLabel
            // 
            this.newLabel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.newLabel.BackColor = System.Drawing.Color.Transparent;
            this.newLabel.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.newLabel.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(65)))), ((int)(((byte)(65)))), ((int)(((byte)(68)))));
            this.newLabel.Location = new System.Drawing.Point(485, 8);
            this.newLabel.Name = "newLabel";
            this.newLabel.Size = new System.Drawing.Size(226, 17);
            this.newLabel.TabIndex = 2;
            this.newLabel.Text = "Selected";
            this.newLabel.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // enableCustomBackgroundCheckBox
            // 
            this.enableCustomBackgroundCheckBox.AutoSize = true;
            this.enableCustomBackgroundCheckBox.BackColor = System.Drawing.Color.Transparent;
            this.enableCustomBackgroundCheckBox.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(65)))), ((int)(((byte)(65)))), ((int)(((byte)(68)))));
            this.enableCustomBackgroundCheckBox.Location = new System.Drawing.Point(18, 9);
            this.enableCustomBackgroundCheckBox.Name = "enableCustomBackgroundCheckBox";
            this.enableCustomBackgroundCheckBox.Size = new System.Drawing.Size(122, 17);
            this.enableCustomBackgroundCheckBox.TabIndex = 0;
            this.enableCustomBackgroundCheckBox.Text = "Custom Background";
            this.enableCustomBackgroundCheckBox.UseVisualStyleBackColor = false;
            this.enableCustomBackgroundCheckBox.CheckedChanged += new System.EventHandler(this.EnableCustomBackgroundCheckBox_CheckedChanged);
            // 
            // monitorsPanel
            // 
            this.monitorsPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(196)))), ((int)(((byte)(198)))), ((int)(((byte)(201)))));
            this.monitorsPanel.BackgroundImage = global::Win7CustomLogonBG.Properties.Resources.monitors;
            this.monitorsPanel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.monitorsPanel.Location = new System.Drawing.Point(183, 58);
            this.monitorsPanel.Name = "monitorsPanel";
            this.monitorsPanel.Size = new System.Drawing.Size(558, 291);
            this.monitorsPanel.TabIndex = 2;
            this.monitorsPanel.Paint += new System.Windows.Forms.PaintEventHandler(this.MonitorsPanel_Paint);
            // 
            // CustomizeLogonBGForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(741, 399);
            this.Controls.Add(this.glassPanel);
            this.DoubleBuffered = true;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.KeyPreview = true;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "CustomizeLogonBGForm";
            this.Text = "Customize Logon Background";
            this.TransparencyKey = System.Drawing.Color.Magenta;
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.CustomizeLogonBGForm_KeyDown);
            this.glassPanel.ResumeLayout(false);
            this.headerPanel.ResumeLayout(false);
            this.headerPanel.PerformLayout();
            this.ResumeLayout(false);
        }

        #endregion Private Methods 

        #endregion Methods 
    }
}

