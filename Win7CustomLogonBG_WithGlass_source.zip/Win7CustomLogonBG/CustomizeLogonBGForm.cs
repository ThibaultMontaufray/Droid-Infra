﻿using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Windows.Forms;
using Windows.Shell;

namespace Win7CustomLogonBG
{
    public partial class CustomizeLogonBGForm : GlassForm
    {
        #region Fields

        private Bitmap currentBackground;

        private Bitmap selectedBackground;

        private Dictionary<string, Bitmap> cache = new Dictionary<string, Bitmap>();

        private static Lazy<Rectangle> currentBGRect = new Lazy<Rectangle>(() => new Rectangle(33, 23, 220, 165));

        private static Lazy<Rectangle> selectedBGRect = new Lazy<Rectangle>(() => new Rectangle(308, 23, 220, 165));

        private ListViewItem selectedItem;

        private string BackgroundDefault = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.System), @"oobe\info\backgrounds\BackgroundDefault.jpg");

        #endregion Fields

        #region Constructors

        public CustomizeLogonBGForm()
        {
            InitializeComponent();

            enableCustomBackgroundCheckBox.Checked = OEMBackground;

            PopulateImageFiles();
        }

        #endregion Constructors

        #region Properties

        public Bitmap CurrentBackground
        {
            get { return currentBackground; }
            set
            {
                if (currentBackground != null)
                {
                    currentBackground.Dispose();
                    currentBackground = null;
                }

                currentBackground = value;
                monitorsPanel.Invalidate();
            }
        }

        public Bitmap SelectedBackground
        {
            get { return selectedBackground; }
            set
            {
                selectedBackground = value;
                monitorsPanel.Invalidate();
            }
        }

        protected bool OEMBackground
        {
            get
            {
                using (var key = Registry.LocalMachine.OpenSubKey(@"SOFTWARE\Microsoft\Windows\CurrentVersion\Authentication\LogonUI\Background"))
                {
                    return key.GetValueNames().Contains("OEMBackground", new RegKeyComparer()) && (int)key.GetValue("OEMBackground") == 1;
                }
            }
            set
            {
                using (var key = Registry.LocalMachine.OpenSubKey(@"SOFTWARE\Microsoft\Windows\CurrentVersion\Authentication\LogonUI\Background", true))
                {
                    key.SetValue("OEMBackground", value ? 1 : 0, RegistryValueKind.DWord);
                }
            }
        }

        public static Rectangle CurrentBGRect
        {
            get { return CustomizeLogonBGForm.currentBGRect.Value; }
        }

        public static Rectangle SelectedBGRect
        {
            get { return CustomizeLogonBGForm.selectedBGRect.Value; }
        }

        #endregion Properties

        #region Methods

        #region Private Methods

        private void ApplyButton_Click(object sender, EventArgs e)
        {
            try
            {
                Directory.CreateDirectory(Path.GetDirectoryName(BackgroundDefault));

                if ((File.GetAttributes(BackgroundDefault) & FileAttributes.ReadOnly) == FileAttributes.ReadOnly)
                    File.SetAttributes(BackgroundDefault, FileAttributes.Normal);

                File.Copy(Path.Combine(Application.StartupPath, "images", selectedItem.Text), BackgroundDefault, true);
                File.SetAttributes(BackgroundDefault, FileAttributes.ReadOnly);

                CurrentBackground = SelectedBackground.Clone() as Bitmap;
            }
            catch (Exception ex) { MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error); }
        }

        private void CustomizeLogonBGForm_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Escape)
                Close();
        }

        private void EnableCustomBackgroundCheckBox_CheckedChanged(object sender, EventArgs e)
        {
            OEMBackground = enableCustomBackgroundCheckBox.Checked;

            listView.Enabled = applyButton.Enabled = OEMBackground;

            UpdateCurrentBGPreview();
        }

        private void ListView_DoubleClick(object sender, EventArgs e)
        {
            if (selectedItem != null)
                applyButton.PerformClick();
        }

        private void ListView_ItemSelectionChanged(object sender, ListViewItemSelectionChangedEventArgs e)
        {
            if (e.IsSelected)
            {
                selectedItem = e.Item;
                var path = (Path.Combine(Application.StartupPath, "images", selectedItem.Text));

                if (cache.ContainsKey(path))
                    SelectedBackground = cache[path];
                else
                {
                    SelectedBackground = new Bitmap(path);
                    cache[path] = SelectedBackground;
                }
            }
        }

        private void MonitorsPanel_Paint(object sender, PaintEventArgs e)
        {
            e.Graphics.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.HighSpeed;

            if (CurrentBackground != null)
                e.Graphics.DrawImage(CurrentBackground, CurrentBGRect);

            if (SelectedBackground != null)
                e.Graphics.DrawImage(SelectedBackground, SelectedBGRect);
        }

        private void PopulateImageFiles()
        {
            listView.Items.Clear();
            var containsFilesTooLarge = false;

            var files = Directory.GetFiles(Path.Combine(Application.StartupPath, "images"), "*.jpg").ToList();

            containsFilesTooLarge = files.FirstOrDefault(f => new FileInfo(f).Length > 1024L * 256) != null;

            if (containsFilesTooLarge)
                files = files.Where(f => new FileInfo(f).Length <= 1024L * 256).ToList();

            files = files.Select(f => Path.GetFileName(f)).ToList();
            files.Sort();

            var index = files.IndexOf("Default.jpg");

            if (index != -1)
            {
                files.RemoveAt(index);
                files.Insert(0, "Default.jpg");
            }

            listView.Items.AddRange(files.Select(f => new ListViewItem(new string[] { f })).ToArray());
            listView.AutoResizeColumns(ColumnHeaderAutoResizeStyle.ColumnContent);

            UpdateCurrentBGPreview();
            listView.Items[0].Selected = true;
        }

        private void RefreshButton_Click(object sender, EventArgs e)
        {
            PopulateImageFiles();
        }

        private void UpdateCurrentBGPreview()
        {
            if (!enableCustomBackgroundCheckBox.Checked)
                CurrentBackground = global::Win7CustomLogonBG.Properties.Resources.Default;
            else if (File.Exists(BackgroundDefault))
            {
                if (OEMBackground && File.Exists(BackgroundDefault))
                {
                    if ((File.GetAttributes(BackgroundDefault) & FileAttributes.ReadOnly) == FileAttributes.ReadOnly)
                        File.SetAttributes(BackgroundDefault, FileAttributes.Normal);

                    using (var stream = new MemoryStream(File.ReadAllBytes(BackgroundDefault)))
                    {
                        CurrentBackground = new Bitmap(stream).Clone() as Bitmap;
                        monitorsPanel.Invalidate();
                    }
                }
            }
        }

        #endregion Private Methods

        #endregion Methods
    }

    /// <summary>A simple <see cref="System.Collections.Generic.IEqualityComparer&lt;string&gt;"/>
    /// implementation to support a case insensitive comparison of registry values.</summary>
    internal class RegKeyComparer : IEqualityComparer<string>
    {
        #region Methods

        #region Public Methods

        public bool Equals(string x, string y)
        {
            return string.Compare(x, y, StringComparison.InvariantCultureIgnoreCase) == 0;
        }

        public int GetHashCode(string obj)
        {
            return obj.GetHashCode();
        }

        #endregion Public Methods

        #endregion Methods
    }
}
