﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;

namespace Romy.Core.Console
{
    /// <summary>A base console type that enables some logging methods. Logs
    /// via TraceListener, to both the console and a file.</summary><remarks>
    /// See Zipper\Program.cs or FormatCSFiles\Program.cs for examples.</remarks>
    public class ConsoleApplicationBase
    {
        private string logFilename;

        /// <summary>Delete the file or directory specified,
        /// without throwing an exception on failure.</summary>
        public static bool DeleteFileSystemObject(string path)
        {
            try
            {
                /* File.Exists seems to return true for directories,
                 * so always check with Directory.Exists first... */
                if (Directory.Exists(path))
                {
                    var info = new DirectoryInfo(path);

                    // If path == current directory, change the current directory.
                    if (string.Compare(Directory.GetCurrentDirectory(), path, StringComparison.InvariantCultureIgnoreCase) == 0 && Directory.Exists(Path.GetDirectoryName(path)))
                        Directory.SetCurrentDirectory(Path.GetDirectoryName(path));

                    // Try to silently delete readonly/hidden directories.
                    if ((info.Attributes & FileAttributes.ReadOnly) == FileAttributes.ReadOnly || (info.Attributes & FileAttributes.Hidden) == FileAttributes.Hidden)
                        info.Attributes = FileAttributes.Directory & FileAttributes.Archive;

                    Directory.Delete(path, true);
                }
                else if (File.Exists(path))
                {
                    // Try to silently delete readonly/hidden files.
                    if ((File.GetAttributes(path) & FileAttributes.ReadOnly) == FileAttributes.ReadOnly || (File.GetAttributes(path) & FileAttributes.Hidden) == FileAttributes.Hidden)
                        File.SetAttributes(path, FileAttributes.Normal);

                    File.Delete(path);
                }
                return true;
            }
            catch (IOException) { }
            catch (UnauthorizedAccessException) { }
            catch (Exception ex) { LogError(ex); }
            return false;
        }

        public static void LogError(Exception ex)
        {
            LogInfo("Error: {0}", ex.Message);
        }

        public static void LogError(string message)
        {
            LogInfo(message);
        }

        public static void LogInfo(IEnumerable<string> lines)
        {
            foreach (var line in lines)
            {
                Trace.WriteLine(line);
            }
        }

        public static void LogInfo(string format, params object[] args)
        {
            var formattedDate = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss.ff\t");
            Trace.WriteLine(formattedDate + (args.Length > 0 ? string.Format(format, args) : format));
        }

        /// <summary>This must be the first method called from Main,
        /// to be able to use the logging helper methods.</summary>
        public void InitializeConsoleApplication()
        {
            /* I prefer removing the parameters from Main and using this technique. It is always
             * consistent; the path to this exe is the first argument, and subsequent arguments
             * were passed by the user. */
            var args = Environment.GetCommandLineArgs();

            logFilename = Path.ChangeExtension(args[0], ".log");

            InitializeTraceListeners(logFilename);
        }

        private static void InitializeTraceListeners(string logFilename)
        {
            DeleteFileSystemObject(logFilename);

            Trace.Listeners.Clear();

            TextWriterTraceListener logFileTraceListener = new TextWriterTraceListener(logFilename);
            logFileTraceListener.Name = "FileLogger";

            ConsoleTraceListener consoleTraceListener = new ConsoleTraceListener(false);
            consoleTraceListener.Name = "ConsoleLogger";

            Trace.Listeners.Add(logFileTraceListener);
            Trace.Listeners.Add(consoleTraceListener);
            Trace.AutoFlush = true;
        }
    }
}
