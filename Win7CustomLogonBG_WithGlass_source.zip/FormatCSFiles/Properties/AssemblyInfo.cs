﻿using System.Reflection;
using System.Resources;
using System.Runtime.InteropServices;

// General Information
[assembly: AssemblyTitle("FormatCSFiles")]
[assembly: AssemblyDescription("RomyView Image and Media Viewer")]
[assembly: AssemblyConfiguration("Debug")]
[assembly: AssemblyCompany("Jerome Viveiros")]
[assembly: AssemblyProduct("FormatCSFiles")]
[assembly: AssemblyCopyright("Copyright © 2013 Jerome Viveiros")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]
// COM Information
[assembly: ComVisible(false)]
[assembly: Guid("fb9e3f4d-c5bc-4f8b-a8c4-c0142a6edef9")]
// Version information
[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersion("1.0.0.0")]
[assembly: NeutralResourcesLanguageAttribute("")]
