using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Windows.Forms;

namespace Win7CustomLogonBG
{
    public partial class CustomizeLogonBGForm : Form
    {
        private string BackgroundDefault = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.System), @"oobe\info\backgrounds\BackgroundDefault.jpg");

        public CustomizeLogonBGForm()
        {
            InitializeComponent();

            enableCustomBackgroundCheckBox.Checked = OEMBackground;

            PopulateImageFiles();
        }

        protected bool OEMBackground
        {
            get
            {
                using (var key = Registry.LocalMachine.OpenSubKey(@"SOFTWARE\Microsoft\Windows\CurrentVersion\Authentication\LogonUI\Background"))
                {
                    return key.GetValueNames().Contains("OEMBackground", new RegKeyComparer()) && (int)key.GetValue("OEMBackground") == 1;
                }
            }
            set
            {
                using (var key = Registry.LocalMachine.OpenSubKey(@"SOFTWARE\Microsoft\Windows\CurrentVersion\Authentication\LogonUI\Background", true))
                {
                    key.SetValue("OEMBackground", value ? 1 : 0, RegistryValueKind.DWord);
                }
            }
        }

        private void ApplyButton_Click(object sender, EventArgs e)
        {
            try
            {
                Directory.CreateDirectory(Path.GetDirectoryName(BackgroundDefault));
                File.Copy(Path.Combine(Application.StartupPath, "images", (string)imagesListBox.SelectedItem), BackgroundDefault, true);
                UpdateCurrentBGPreview();
            }
            catch (Exception ex) { MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error); }
        }

        private void EnableCustomBackgroundCheckBox_CheckedChanged(object sender, EventArgs e)
        {
            OEMBackground = enableCustomBackgroundCheckBox.Checked;

            imagesListBox.Enabled = previewPictureBox.Enabled = applyButton.Enabled = OEMBackground;

            UpdateCurrentBGPreview();
        }

        private void ImagesListBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            previewPictureBox.Image = new Bitmap((Path.Combine(Application.StartupPath, "images", (string)imagesListBox.SelectedItem)));
        }

        private void PopulateImageFiles()
        {
            imagesListBox.Items.Clear();
            var containsFilesTooLarge = false;

            var files = Directory.GetFiles(Path.Combine(Application.StartupPath, "images"), "*.jpg");

            containsFilesTooLarge = files.FirstOrDefault(f => new FileInfo(f).Length > 1024L * 256) != null;

            if (containsFilesTooLarge)
                files = files.Where(f => new FileInfo(f).Length <= 1024L * 256).ToArray();

            files = files.Select(f => Path.GetFileName(f)).ToArray();

            imagesListBox.Items.AddRange(files);

            if (enableCustomBackgroundCheckBox.Checked && File.Exists(BackgroundDefault))
                UpdateCurrentBGPreview();

            imagesListBox.SelectedIndex = 0;
        }

        private void RefreshButton_Click(object sender, EventArgs e)
        {
            PopulateImageFiles();
        }

        private void UpdateCurrentBGPreview()
        {
            if (!enableCustomBackgroundCheckBox.Checked)
                currentBGPreviewPictureBox.Image = global::Win7CustomLogonBG.Properties.Resources.background;
            else if (File.Exists(BackgroundDefault))
            {
                if ((File.GetAttributes(BackgroundDefault) & FileAttributes.ReadOnly) == FileAttributes.ReadOnly)
                    File.SetAttributes(BackgroundDefault, FileAttributes.Normal);

                using (var stream = new MemoryStream(File.ReadAllBytes(BackgroundDefault)))
                {
                    currentBGPreviewPictureBox.Image = new Bitmap(stream);
                }
            }
        }

        private void CustomizeLogonBGForm_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Escape)
                Close();
        }
    }

    /// <summary>A simple <see cref="System.Collections.Generic.IEqualityComparer&lt;string&gt;"/>
    /// implementation to support a case insensitive comparison of registry values.</summary>
    internal class RegKeyComparer : IEqualityComparer<string>
    {
        public bool Equals(string x, string y)
        {
            return string.Compare(x, y, StringComparison.InvariantCultureIgnoreCase) == 0;
        }

        public int GetHashCode(string obj)
        {
            return (obj as string).GetHashCode();
        }
    }
}
