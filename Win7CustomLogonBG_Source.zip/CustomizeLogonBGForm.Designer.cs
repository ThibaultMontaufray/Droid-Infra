namespace Win7CustomLogonBG
{
    partial class CustomizeLogonBGForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;
        private System.Windows.Forms.Button applyButton;
        private System.Windows.Forms.Button refreshButton;
        private System.Windows.Forms.CheckBox enableCustomBackgroundCheckBox;
        private System.Windows.Forms.Label currentLabel;
        private System.Windows.Forms.Label newLabel;
        private System.Windows.Forms.ListBox imagesListBox;
        private System.Windows.Forms.PictureBox currentBGPreviewPictureBox;
        private System.Windows.Forms.PictureBox currentPreviewPictureBox;
        private System.Windows.Forms.PictureBox previewPictureBox;
        private System.Windows.Forms.PictureBox selectedPreviewPictureBox;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.enableCustomBackgroundCheckBox = new System.Windows.Forms.CheckBox();
            this.imagesListBox = new System.Windows.Forms.ListBox();
            this.applyButton = new System.Windows.Forms.Button();
            this.currentLabel = new System.Windows.Forms.Label();
            this.newLabel = new System.Windows.Forms.Label();
            this.refreshButton = new System.Windows.Forms.Button();
            this.currentPreviewPictureBox = new System.Windows.Forms.PictureBox();
            this.currentBGPreviewPictureBox = new System.Windows.Forms.PictureBox();
            this.previewPictureBox = new System.Windows.Forms.PictureBox();
            this.selectedPreviewPictureBox = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.currentPreviewPictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.currentBGPreviewPictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.previewPictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.selectedPreviewPictureBox)).BeginInit();
            this.SuspendLayout();
            // 
            // enableCustomBackgroundCheckBox
            // 
            this.enableCustomBackgroundCheckBox.AutoSize = true;
            this.enableCustomBackgroundCheckBox.Location = new System.Drawing.Point(12, 8);
            this.enableCustomBackgroundCheckBox.Name = "enableCustomBackgroundCheckBox";
            this.enableCustomBackgroundCheckBox.Size = new System.Drawing.Size(122, 17);
            this.enableCustomBackgroundCheckBox.TabIndex = 0;
            this.enableCustomBackgroundCheckBox.Text = "Custom Background";
            this.enableCustomBackgroundCheckBox.UseVisualStyleBackColor = true;
            this.enableCustomBackgroundCheckBox.CheckedChanged += new System.EventHandler(this.EnableCustomBackgroundCheckBox_CheckedChanged);
            // 
            // imagesListBox
            // 
            this.imagesListBox.Enabled = false;
            this.imagesListBox.FormattingEnabled = true;
            this.imagesListBox.Location = new System.Drawing.Point(12, 31);
            this.imagesListBox.Name = "imagesListBox";
            this.imagesListBox.Size = new System.Drawing.Size(120, 264);
            this.imagesListBox.TabIndex = 1;
            this.imagesListBox.SelectedIndexChanged += new System.EventHandler(this.ImagesListBox_SelectedIndexChanged);
            // 
            // applyButton
            // 
            this.applyButton.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.applyButton.Enabled = false;
            this.applyButton.Location = new System.Drawing.Point(436, 306);
            this.applyButton.Name = "applyButton";
            this.applyButton.Size = new System.Drawing.Size(221, 23);
            this.applyButton.TabIndex = 5;
            this.applyButton.Text = "Apply selected background";
            this.applyButton.UseVisualStyleBackColor = true;
            this.applyButton.Click += new System.EventHandler(this.ApplyButton_Click);
            // 
            // currentLabel
            // 
            this.currentLabel.AutoSize = true;
            this.currentLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.currentLabel.Location = new System.Drawing.Point(251, 10);
            this.currentLabel.Name = "currentLabel";
            this.currentLabel.Size = new System.Drawing.Size(41, 13);
            this.currentLabel.TabIndex = 2;
            this.currentLabel.Text = "Current";
            // 
            // newLabel
            // 
            this.newLabel.AutoSize = true;
            this.newLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.newLabel.Location = new System.Drawing.Point(509, 10);
            this.newLabel.Name = "newLabel";
            this.newLabel.Size = new System.Drawing.Size(49, 13);
            this.newLabel.TabIndex = 3;
            this.newLabel.Text = "Selected";
            // 
            // refreshButton
            // 
            this.refreshButton.Location = new System.Drawing.Point(12, 306);
            this.refreshButton.Name = "refreshButton";
            this.refreshButton.Size = new System.Drawing.Size(120, 23);
            this.refreshButton.TabIndex = 4;
            this.refreshButton.Text = "Refresh";
            this.refreshButton.UseVisualStyleBackColor = true;
            this.refreshButton.Click += new System.EventHandler(this.RefreshButton_Click);
            // 
            // currentPreviewPictureBox
            // 
            this.currentPreviewPictureBox.Image = global::Win7CustomLogonBG.Properties.Resources.monitor;
            this.currentPreviewPictureBox.Location = new System.Drawing.Point(151, 31);
            this.currentPreviewPictureBox.Name = "currentPreviewPictureBox";
            this.currentPreviewPictureBox.Size = new System.Drawing.Size(240, 258);
            this.currentPreviewPictureBox.TabIndex = 6;
            this.currentPreviewPictureBox.TabStop = false;
            // 
            // currentBGPreviewPictureBox
            // 
            this.currentBGPreviewPictureBox.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.currentBGPreviewPictureBox.Enabled = false;
            this.currentBGPreviewPictureBox.Image = global::Win7CustomLogonBG.Properties.Resources.background;
            this.currentBGPreviewPictureBox.Location = new System.Drawing.Point(161, 44);
            this.currentBGPreviewPictureBox.Name = "currentBGPreviewPictureBox";
            this.currentBGPreviewPictureBox.Size = new System.Drawing.Size(220, 165);
            this.currentBGPreviewPictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.currentBGPreviewPictureBox.TabIndex = 4;
            this.currentBGPreviewPictureBox.TabStop = false;
            // 
            // previewPictureBox
            // 
            this.previewPictureBox.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.previewPictureBox.Enabled = false;
            this.previewPictureBox.Location = new System.Drawing.Point(423, 44);
            this.previewPictureBox.Name = "previewPictureBox";
            this.previewPictureBox.Size = new System.Drawing.Size(220, 165);
            this.previewPictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.previewPictureBox.TabIndex = 2;
            this.previewPictureBox.TabStop = false;
            // 
            // selectedPreviewPictureBox
            // 
            this.selectedPreviewPictureBox.Image = global::Win7CustomLogonBG.Properties.Resources.monitor;
            this.selectedPreviewPictureBox.Location = new System.Drawing.Point(413, 31);
            this.selectedPreviewPictureBox.Name = "selectedPreviewPictureBox";
            this.selectedPreviewPictureBox.Size = new System.Drawing.Size(240, 258);
            this.selectedPreviewPictureBox.TabIndex = 6;
            this.selectedPreviewPictureBox.TabStop = false;
            // 
            // CustomizeLogonBGForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(670, 342);
            this.Controls.Add(this.currentBGPreviewPictureBox);
            this.Controls.Add(this.currentLabel);
            this.Controls.Add(this.previewPictureBox);
            this.Controls.Add(this.selectedPreviewPictureBox);
            this.Controls.Add(this.currentPreviewPictureBox);
            this.Controls.Add(this.refreshButton);
            this.Controls.Add(this.newLabel);
            this.Controls.Add(this.applyButton);
            this.Controls.Add(this.imagesListBox);
            this.Controls.Add(this.enableCustomBackgroundCheckBox);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.KeyPreview = true;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "CustomizeLogonBGForm";
            this.Text = "Customize Logon Background";
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.CustomizeLogonBGForm_KeyDown);
            ((System.ComponentModel.ISupportInitialize)(this.currentPreviewPictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.currentBGPreviewPictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.previewPictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.selectedPreviewPictureBox)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();
        }
    }
}

